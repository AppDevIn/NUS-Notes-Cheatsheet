void init_barrier(int);
void reach_barrier();
void destroy_barrier(int);
