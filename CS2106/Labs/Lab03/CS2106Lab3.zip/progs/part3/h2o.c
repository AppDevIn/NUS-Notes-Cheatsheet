/**
 * CS2106 AY 25/26 Semester 1 - Lab 3
 *
 * Your implementation should be in this file.
 */

#include "h2o.h"

static H2O h2o;


// Your initialization code goes here
void h2o_init() {

}

// Synchronization code for hydrogen thread
void hydrogen_thread(void (*releaseHydrogen)(void)) {

}

// Synchronization code for oxygen thread
void oxygen_thread(void (*releaseOxygen)(void)) {

}

// Your cleanup code goes here
void h2o_destroy() {

}
