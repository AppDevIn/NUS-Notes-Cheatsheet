
// Maximum number of elements in a stack
//
#define MAX_STACK_SIZE 10

// declare prototypes below
