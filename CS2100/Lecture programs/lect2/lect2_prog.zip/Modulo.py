def main():
  a =  10 %  4
  b = -10 %  4
  c =  10 % -4
  d = -10 % -4
  print(a, b, c, d)
  return 0

if __name__ == "__main__":
  main()
