def main():
  # to show left associativity
  print("46 / 15 / 2 =", 46/15/2)
  # to show Python's floor division
  print("46 // 15 // 2 =", 46//15//2)
  print("19 % 7 % 3 =", 19%7%3)

  x = -23
  p = +4 * 10
  print("x =", x)
  print("p =", p)

  n = int(9 * 0.5)
  print("n =", n)
  
  return 0

if __name__ == "__main__":
  main()
