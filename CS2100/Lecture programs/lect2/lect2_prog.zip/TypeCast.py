def main():
  aa = 6
  ff = 15.8

  pp = float(aa) / 4
  nn = int(ff) // aa
  qq = float(aa / 4)

  print("pp =", pp)
  print("nn =", nn)
  print("qq =", qq)

  return 0

if __name__ == "__main__":
  main()
