// InitVariable.c
int main(void) {
	int count;
	count = count + 12;
	return 0;
}
