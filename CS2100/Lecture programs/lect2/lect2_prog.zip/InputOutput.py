def main():
  # No need for variable declaration
  age = int(input("What is your age? "))
  # Prompt together with input reading
  cap = float(input("What is your CAP? "))
  # There’s no double, only float
  print("You are", age, "years old, and your CAP is", cap);

  return 0

if __name__ == "__main__":
  main()
