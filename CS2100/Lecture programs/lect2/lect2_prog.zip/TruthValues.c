// TruthValues.c
#include <stdio.h>

int main(void) {    
	int a = (2 > 3);
	int b = (3 > 2);

	printf("a = %d; b = %d\n", a, b);

	return 0;
}

