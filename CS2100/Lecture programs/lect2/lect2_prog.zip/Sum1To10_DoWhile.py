def main():
  sum,i = 0,1

  sum = sum + i
  i = i + 1
  while i <= 10:
    sum = sum + i
    i = i + 1

  print("sum =", sum)

  return 0

if __name__ == "__main__":
  main()
