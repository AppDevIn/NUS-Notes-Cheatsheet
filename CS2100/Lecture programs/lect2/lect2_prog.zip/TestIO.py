def main():
  a = int(input("Enter an integer: "))
  print("Value entered:", a)

  f = float(input("Enter a real number: "))
  print("Value entered:", f)

  return 0

if __name__ == "__main__":
  main()
