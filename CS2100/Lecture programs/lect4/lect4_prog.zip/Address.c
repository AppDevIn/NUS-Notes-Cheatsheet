// Address.c 
#include <stdio.h>

int main(void) {    
	int a = 123;

	printf("a = %d\n", a);
	printf("&a = %p\n", &a);

	return 0;
}

