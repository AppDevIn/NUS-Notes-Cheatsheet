def hi():
    return "Hello!"
