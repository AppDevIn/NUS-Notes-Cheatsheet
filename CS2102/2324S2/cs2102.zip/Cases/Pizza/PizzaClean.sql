DROP TABLE sells;
DROP TABLE likes;
DROP TABLE pizza;
DROP TABLE restaurant;
DROP TABLE customer;
