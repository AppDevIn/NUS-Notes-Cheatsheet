/*******************

  Cleaning script

*******************/

DROP TABLE IF EXISTS downloads;
DROP TABLE IF EXISTS games;
DROP TABLE IF EXISTS customers;