/*******************
Cleaning script
*******************/

DROP TABLE IF EXISTS sprint_results;
DROP TABLE IF EXISTS qualifyings;
DROP TABLE IF EXISTS pit_stops;
DROP TABLE IF EXISTS constructor_results;
DROP TABLE IF EXISTS results;
DROP TABLE IF EXISTS races;
DROP TABLE IF EXISTS statuses;
DROP TABLE IF EXISTS constructors;
DROP TABLE IF EXISTS drivers;
DROP TABLE IF EXISTS circuits;
DROP TABLE IF EXISTS seasons;
DROP TABLE IF EXISTS countries;