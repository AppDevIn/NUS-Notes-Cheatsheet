/*******************

  Cleaning script

*******************/

DROP TABLE IF EXISTS loan;
DROP TABLE IF EXISTS copy;
DROP TABLE IF EXISTS student;
DROP TABLE IF EXISTS book;